This resources archive is intentionally minimal.
Add icon.png (64x64) and other shared resources here.
